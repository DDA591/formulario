const DEFAULT_ALLOWED_ORIGIN = 'https://dda591.github.io';
const DEFAULT_UPSTREAM_URL = 'https://ficha-anamnese-clau-estetica.ddiasanacleto.chatgpt.site/api/send-form';

function allowedOrigins(env) {
  return String(env.ALLOWED_ORIGIN || DEFAULT_ALLOWED_ORIGIN)
    .split(',')
    .map((origin) => origin.trim().replace(/\/+$/, ''))
    .filter(Boolean);
}

function corsHeaders(request, env) {
  const headers = new Headers({ Vary: 'Origin' });
  const origin = request.headers.get('Origin');
  if (origin && allowedOrigins(env).includes(origin)) {
    headers.set('Access-Control-Allow-Origin', origin);
    headers.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
    headers.set('Access-Control-Allow-Headers', 'Content-Type');
  }
  return headers;
}

function json(request, env, body, status = 200) {
  const headers = corsHeaders(request, env);
  headers.set('Content-Type', 'application/json; charset=UTF-8');
  return new Response(JSON.stringify(body), { status, headers });
}

async function forwardForm(request, env) {
  const origin = request.headers.get('Origin');
  if (!origin || !allowedOrigins(env).includes(origin)) {
    return json(request, env, { error: 'Origem não autorizada.' }, 403);
  }

  const contentType = request.headers.get('Content-Type') || '';
  if (!contentType.includes('application/json')) {
    return json(request, env, { error: 'Formato inválido.' }, 415);
  }

  const body = await request.text();
  if (!body || body.length > 100000) return json(request, env, { error: 'Dados inválidos.' }, 400);

  try {
    const parsed = JSON.parse(body);
    if (!parsed?.values || typeof parsed.values !== 'object') throw new Error('Dados ausentes');
  } catch {
    return json(request, env, { error: 'Dados inválidos.' }, 400);
  }

  try {
    const upstreamResponse = await fetch(env.UPSTREAM_FORM_URL || DEFAULT_UPSTREAM_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
    });
    if (!upstreamResponse.ok) {
      console.error('Serviço de e-mail respondeu com erro:', upstreamResponse.status);
      return json(request, env, { error: 'Não foi possível enviar a ficha.' }, 502);
    }
    return json(request, env, { ok: true });
  } catch (error) {
    console.error('Falha ao contactar o serviço de e-mail:', error);
    return json(request, env, { error: 'Não foi possível enviar a ficha.' }, 502);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/send-form') {
      if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(request, env) });
      if (request.method === 'POST') return forwardForm(request, env);
      return json(request, env, { error: 'Método não permitido.' }, 405);
    }

    if (url.pathname === '/health') {
      try {
        const upstream = await fetch(env.UPSTREAM_FORM_URL || DEFAULT_UPSTREAM_URL, { method: 'GET' });
        return Response.json({ ok: upstream.status === 405, upstreamStatus: upstream.status });
      } catch {
        return Response.json({ ok: false }, { status: 502 });
      }
    }

    return new Response('Não encontrado.', { status: 404 });
  },
};
