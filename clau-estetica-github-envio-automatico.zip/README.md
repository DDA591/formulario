# Clau Estética — GitHub Pages com envio automático

Todos os arquivos estão juntos nesta pasta. O GitHub Pages hospeda a página; o Cloudflare Worker conecta a página ao serviço de e-mail já configurado, sem colocar credenciais do Gmail no GitHub.

## Pronto para o GitHub

O serviço de envio já está configurado no arquivo `form-api.js`. Envie todos os arquivos desta pasta para a raiz do repositório no GitHub.

O arquivo `worker.js` e os arquivos de configuração ficam no mesmo repositório, mas não são executados pelo GitHub Pages. Eles são a cópia de segurança do serviço publicado na Cloudflare.
