# Clau Estética — Ficha Digital

Todos os arquivos deste projeto estão nesta mesma pasta, prontos para serem enviados à raiz de um repositório do GitHub.

## Publicação com Cloudflare Workers

1. Envie todos os arquivos para a raiz do repositório no GitHub.
2. Instale o Wrangler e entre na sua conta Cloudflare:

   ```bash
   npm install -g wrangler
   wrangler login
   ```

3. No painel da Cloudflare, configure estas variáveis:

   - `GMAIL_CLIENT_ID`
   - `GMAIL_CLIENT_SECRET`
   - `GMAIL_REFRESH_TOKEN`
   - `GMAIL_SENDER_EMAIL`
   - `FORM_RECIPIENT_EMAIL`

4. Execute `npm run deploy`.

Para testar no computador, crie um arquivo `.dev.vars` com essas variáveis e execute `npm run dev`. Nunca envie `.dev.vars` ao GitHub.
