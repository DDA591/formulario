export type FormValues = Record<string, string | string[] | boolean>;

export const FIELD_LABELS: Record<string, string> = {
  fullName: 'Nome completo',
  birthDate: 'Data de nascimento',
  phone: 'WhatsApp',
  email: 'E-mail',
  procedure: 'Procedimento',
  otherProcedure: 'Outro procedimento',
  objective: 'Principal objetivo',
  previousProcedure: 'Já realizou esse procedimento?',
  previousResult: 'Experiência anterior e resultado',
  healthConditions: 'Condições de saúde',
  medicalTreatment: 'Tratamento médico atual?',
  medications: 'Usa medicamentos?',
  allergies: 'Possui alergias?',
  surgery: 'Passou por cirurgia?',
  pregnancy: 'Grávida ou possibilidade?',
  breastfeeding: 'Está amamentando?',
  healthDetails: 'Informações de saúde adicionais',
  skinPain: 'Dor, febre, inflamação, infecção ou lesão na área?',
  skinType: 'Tipo de pele',
  skinConditions: 'Condições da pele',
  acids: 'Usa ou usou ácidos recentemente?',
  facialProcedure: 'Procedimento facial recente?',
  circulation: 'Possui varizes ou alteração circulatória?',
  restrictedArea: 'Há região que não deve ser manipulada?',
  skinDetails: 'Detalhes adicionais da pele',
  sunExposure: 'Exposição solar sem proteção?',
  skincareRoutine: 'Possui rotina de cuidados com a pele?',
  sunscreen: 'Usa protetor solar?',
  hormones: 'Usa hormônios ou anticoncepcional?',
  habitsDetails: 'Produtos, hábitos ou observações',
  dataConsent: 'Consentimento de dados',
  imageConsent: 'Autorização de imagem',
  confirmationDate: 'Data da confirmação',
  confirmed: 'Confirmação eletrônica',
};

export function asText(value: FormValues[string] | undefined) {
  if (Array.isArray(value)) return value.length ? value.join(', ') : 'Não informado';
  if (typeof value === 'boolean') return value ? 'Sim' : 'Não';
  return value?.trim() || 'Não informado';
}

export function formLines(values: FormValues) {
  return Object.entries(FIELD_LABELS).map(([key, label]) => `${label}: ${asText(values[key])}`);
}

type PdfLine = { text: string; bold?: boolean; indent?: number };

const PAGE_WIDTH = 595;
const PAGE_HEIGHT = 842;
const MARGIN = 48;
const BODY_TOP = 732;
const BODY_BOTTOM = 62;
const LINE_HEIGHT = 13;

function ascii(value: string) {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x20-\x7E]/g, '?');
}

function escapePdf(value: string) {
  return ascii(value).replace(/([\\()])/g, '\\$1');
}

function wrap(value: string, width: number) {
  const words = ascii(value).replace(/\s+/g, ' ').trim().split(' ');
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length <= width) {
      current = candidate;
      continue;
    }
    if (current) lines.push(current);
    if (word.length > width) {
      for (let index = 0; index < word.length; index += width) lines.push(word.slice(index, index + width));
      current = '';
    } else {
      current = word;
    }
  }

  if (current) lines.push(current);
  return lines.length ? lines : ['Não informado'];
}

function createPages(values: FormValues) {
  const entries: PdfLine[] = [];
  for (const [key, label] of Object.entries(FIELD_LABELS)) {
    entries.push({ text: label, bold: true });
    for (const line of wrap(asText(values[key]), 78)) entries.push({ text: line, indent: 12 });
    entries.push({ text: '', indent: 0 });
  }

  const pages: PdfLine[][] = [[]];
  let usedHeight = 0;
  const availableHeight = BODY_TOP - BODY_BOTTOM;
  for (const entry of entries) {
    if (usedHeight + LINE_HEIGHT > availableHeight) {
      pages.push([]);
      usedHeight = 0;
    }
    pages.at(-1)?.push(entry);
    usedHeight += LINE_HEIGHT;
  }
  return pages;
}

function pageStream(lines: PdfLine[], pageNumber: number, totalPages: number) {
  const operations = [
    'q',
    '0.58 0.48 0.22 rg',
    `0.7 w ${MARGIN} 758 m ${PAGE_WIDTH - MARGIN} 758 l S`,
    '0 0 0 rg',
    'BT',
    '/F2 18 Tf',
    `1 0 0 1 ${MARGIN} 790 Tm`,
    `(FICHA DIGITAL DE ANAMNESE) Tj`,
    '/F1 9 Tf',
    `1 0 0 1 ${MARGIN} 773 Tm`,
    `(Clau Estetica - formulario recebido) Tj`,
    `1 0 0 1 ${PAGE_WIDTH - 110} 773 Tm`,
    `(Pagina ${pageNumber} de ${totalPages}) Tj`,
    'ET',
  ];

  let y = BODY_TOP;
  for (const line of lines) {
    if (line.text) {
      operations.push('BT');
      operations.push(`/${line.bold ? 'F2' : 'F1'} ${line.bold ? 9.5 : 9} Tf`);
      operations.push(`1 0 0 1 ${MARGIN + (line.indent ?? 0)} ${y} Tm`);
      operations.push(`(${escapePdf(line.text)}) Tj`);
      operations.push('ET');
    }
    y -= LINE_HEIGHT;
  }

  operations.push('Q');
  return operations.join('\n');
}

export function createFormPdf(values: FormValues) {
  const pages = createPages(values);
  const objects: string[] = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>',
  ];

  const pageObjectIds: number[] = [];
  pages.forEach((page, index) => {
    const content = pageStream(page, index + 1, pages.length);
    const contentId = objects.length + 1;
    const pageId = contentId + 1;
    objects.push(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
    objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_WIDTH} ${PAGE_HEIGHT}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentId} 0 R >>`);
    pageObjectIds.push(pageId);
  });

  objects[1] = `<< /Type /Pages /Kids [${pageObjectIds.map((id) => `${id} 0 R`).join(' ')}] /Count ${pageObjectIds.length} >>`;

  let output = '%PDF-1.4\n%----\n';
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(output.length);
    output += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = output.length;
  output += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let index = 1; index < offsets.length; index += 1) output += `${String(offsets[index]).padStart(10, '0')} 00000 n \n`;
  output += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  return new TextEncoder().encode(output);
}
