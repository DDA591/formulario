import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Ficha de Anamnese | Clau Estética',
  description: 'Ficha digital de anamnese e declaração de ciência.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
