'use client';

import { FormEvent, ReactNode, useState } from 'react';

type Values = Record<string, string | string[] | boolean>;

const YES_NO = [
  { value: 'sim', label: 'Sim' },
  { value: 'nao', label: 'Não' },
];

const HEALTH_CONDITIONS = [
  'Diabetes', 'Hipertensão', 'Problemas cardíacos', 'Problemas circulatórios',
  'Trombose', 'Varizes', 'Epilepsia', 'Doença autoimune',
  'Tratamento oncológico', 'Nenhuma', 'Outra',
];

const SKIN_CONDITIONS = [
  'Acne', 'Manchas ou melasma', 'Rosácea ou dermatite',
  'Sensibilidade', 'Feridas ou lesões', 'Nenhuma',
];

const INITIAL_VALUES: Values = {
  fullName: '', birthDate: '', phone: '', email: '',
  procedure: '', otherProcedure: '', objective: '', previousProcedure: '', previousResult: '',
  healthConditions: [], medicalTreatment: '', medications: '', allergies: '', surgery: '',
  pregnancy: '', breastfeeding: '', healthDetails: '', skinPain: '', skinType: '',
  skinConditions: [], acids: '', facialProcedure: '', circulation: '', restrictedArea: '',
  skinDetails: '', sunExposure: '', skincareRoutine: '', sunscreen: '', hormones: '',
  habitsDetails: '', dataConsent: '', imageConsent: '', confirmationDate: '', confirmed: false,
};

function formatBrazilianPhone(value: string) {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 2) return digits ? `(${digits}` : '';
  if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function Field({ label, required = false, children }: { label: string; required?: boolean; children: ReactNode }) {
  return <label className="field-label">{label} {required && <em>*</em>}{children}</label>;
}

function ChoiceCards({ name, value, options, onChange }: { name: string; value: string; options: { value: string; label: string }[]; onChange: (value: string) => void }) {
  return (
    <div className="choice-cards" role="radiogroup" aria-label={name}>
      {options.map((option) => (
        <label className="choice-card" key={option.value}>
          <input type="radio" name={name} value={option.value} checked={value === option.value} onChange={() => onChange(option.value)} required />
          <span>{option.label}</span>
        </label>
      ))}
    </div>
  );
}

function CheckboxGrid({ values, options, onChange, columns = 2 }: { values: string[]; options: string[]; onChange: (values: string[]) => void; columns?: 1 | 2 }) {
  function toggle(option: string) {
    const isNone = option === 'Nenhuma';
    if (isNone) return onChange(values.includes(option) ? [] : [option]);
    const withoutNone = values.filter((item) => item !== 'Nenhuma');
    onChange(withoutNone.includes(option) ? withoutNone.filter((item) => item !== option) : [...withoutNone, option]);
  }

  return (
    <div className={`check-grid check-grid-${columns}`}>
      {options.map((option) => (
        <label className="check-card" key={option}>
          <input type="checkbox" checked={values.includes(option)} onChange={() => toggle(option)} />
          <span>{option}</span>
        </label>
      ))}
    </div>
  );
}

export default function Home() {
  const [step, setStep] = useState(1);
  const [values, setValues] = useState<Values>(INITIAL_VALUES);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const update = (key: string, value: string | string[] | boolean) => {
    setValues((current) => ({ ...current, [key]: value }));
    setError('');
  };

  const select = (key: string, label: string, required = true, options = YES_NO) => (
    <Field label={label} required={required}>
      <select value={String(values[key])} onChange={(event) => update(key, event.target.value)} required={required}>
        <option value="">Selecione</option>
        {options.map((option) => <option value={option.value} key={option.value}>{option.label}</option>)}
      </select>
    </Field>
  );

  function validateStep() {
    if (step === 1 && !isValidEmail(String(values.email))) {
      setError('Digite um e-mail válido, como nome@dominio.com.');
      return false;
    }
    if (step === 3 && !(values.healthConditions as string[]).length) {
      setError('Selecione ao menos uma condição de saúde.');
      return false;
    }
    return true;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!validateStep()) return;

    if (step !== 7) {
      setStep((current) => current + 1);
      return;
    }

    setIsSending(true);
    setError('');

    try {
      const response = await fetch('/api/send-form', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ values }),
      });

      if (!response.ok) throw new Error('Não foi possível enviar a ficha.');
      setSubmitted(true);
    } catch {
      setError('Não foi possível enviar a ficha agora. Verifique sua conexão e tente novamente.');
    } finally {
      setIsSending(false);
    }
  }

  function goBack() {
    setError('');
    setStep((current) => Math.max(1, current - 1));
  }

  const title = [
    '1. Identificação',
    '2. Atendimento desejado',
    '3. Informações de saúde',
    '4. Avaliação estética',
    '5. Rotina e hábitos',
    '6. Privacidade e imagem',
    '7. Confirmação eletrônica',
  ][step - 1];

  if (submitted) {
    return (
      <main className="site-shell">
        <Brand />
        <section className="form-area">
          <div className="form-card success-card" role="status">
            <div className="success-icon">✓</div>
            <h1>Ficha recebida</h1>
            <p>Obrigada, {String(values.fullName || 'cliente')}. Sua ficha foi enviada ao e-mail responsável pelo atendimento.</p>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="site-shell">
      <Brand />
      <section className="form-area" aria-labelledby="form-title">
        <form className="form-card" onSubmit={handleSubmit}>
          <div className="progress-zone">
            <div className="progress-track" aria-hidden="true"><div className="progress-fill" style={{ width: `${(step / 7) * 100}%` }} /></div>
            <span>Etapa {step} de 7</span>
          </div>

          <div className="form-content">
            <h1 id="form-title">{title}</h1>
            <div className="section-rule" />
            {step === 1 && <Identification values={values} update={update} />}
            {step === 2 && <DesiredCare values={values} update={update} />}
            {step === 3 && <HealthInfo values={values} update={update} select={select} />}
            {step === 4 && <AestheticAssessment values={values} update={update} select={select} />}
            {step === 5 && <Habits values={values} update={update} select={select} />}
            {step === 6 && <Privacy values={values} update={update} select={select} />}
            {step === 7 && <Confirmation values={values} update={update} />}
          </div>

          {error && <p className="form-error" role="alert">{error}</p>}
          <footer className={`form-actions ${step === 1 ? 'form-actions-end' : ''}`}>
            {step > 1 && <button className="button button-secondary" type="button" onClick={goBack}>Voltar</button>}
            <button className="button button-primary" type="submit" disabled={isSending}>{step === 7 ? (isSending ? 'Enviando...' : 'Enviar ficha') : 'Continuar'}</button>
          </footer>
        </form>
      </section>
    </main>
  );
}

function Brand() {
  return <header className="brand-header"><img className="brand-mark" src="/clau-symbol.png" alt="Símbolo Clau Estética" /><div className="brand-name">Clau Estética</div><div className="brand-role">ENFERMEIRA</div><p>Ficha Digital de Anamnese e Declaração de Ciência</p></header>;
}

function Identification({ values, update }: { values: Values; update: (key: string, value: string) => void }) {
  const email = String(values.email);
  const emailIsInvalid = email.length > 0 && !isValidEmail(email);

  return <>
    <aside className="notice">Preencha esta ficha com atenção. As informações serão usadas para avaliar a segurança do atendimento.<br />Campos marcados com * são obrigatórios.</aside>
    <div className="field-grid">
      <Field label="Nome completo" required><input value={String(values.fullName)} onChange={(event) => update('fullName', event.target.value)} required autoComplete="name" /></Field>
      <Field label="Data de nascimento" required><input type="date" value={String(values.birthDate)} onChange={(event) => update('birthDate', event.target.value)} required autoComplete="bday" /></Field>
      <Field label="WhatsApp" required><input type="tel" value={String(values.phone)} onChange={(event) => update('phone', formatBrazilianPhone(event.target.value))} placeholder="(11) 99999-9999" maxLength={15} inputMode="numeric" required autoComplete="tel" /></Field>
      <Field label="E-mail" required><input type="email" value={email} onChange={(event) => update('email', event.target.value)} aria-invalid={emailIsInvalid} aria-describedby={emailIsInvalid ? 'email-warning' : undefined} required autoComplete="email" />{emailIsInvalid && <span className="field-warning" id="email-warning" role="alert">Digite um e-mail válido, como nome@dominio.com.</span>}</Field>
    </div>
  </>;
}

function DesiredCare({ values, update }: { values: Values; update: (key: string, value: string) => void }) {
  return <div className="stack">
    <Field label="Procedimento" required><select value={String(values.procedure)} onChange={(event) => update('procedure', event.target.value)} required><option value="">Selecione</option><option>Limpeza de pele</option><option>Peeling</option><option>Microagulhamento</option><option>Massagem modeladora</option><option>Outro procedimento</option></select></Field>
    {values.procedure === 'Outro procedimento' && <Field label="Qual procedimento deseja realizar?" required><input value={String(values.otherProcedure)} onChange={(event) => update('otherProcedure', event.target.value)} required autoComplete="off" /></Field>}
    <Field label="Principal objetivo" required><textarea value={String(values.objective)} onChange={(event) => update('objective', event.target.value)} required rows={4} /></Field>
    <Field label="Já realizou esse procedimento?" required><ChoiceCards name="previousProcedure" value={String(values.previousProcedure)} options={YES_NO} onChange={(value) => update('previousProcedure', value)} /></Field>
    <Field label="Se sim, informe quando e como foi o resultado"><textarea value={String(values.previousResult)} onChange={(event) => update('previousResult', event.target.value)} rows={4} /></Field>
  </div>;
}

function HealthInfo({ values, update, select }: { values: Values; update: (key: string, value: string | string[]) => void; select: (key: string, label: string, required?: boolean, options?: { value: string; label: string }[]) => ReactNode }) {
  return <div className="stack">
    <Field label="Marque as condições que possui ou já apresentou" required><CheckboxGrid values={values.healthConditions as string[]} options={HEALTH_CONDITIONS} onChange={(selection) => update('healthConditions', selection)} /></Field>
    <div className="field-grid compact-grid">
      {select('medicalTreatment', 'Tratamento médico atual?')}
      {select('medications', 'Usa medicamentos?')}
      {select('allergies', 'Possui alergias?')}
      {select('surgery', 'Passou por cirurgia?')}
      {select('pregnancy', 'Grávida ou possibilidade?')}
      {select('breastfeeding', 'Está amamentando?')}
    </div>
    <Field label="Medicamentos, alergias, cirurgias, tratamentos ou outras informações importantes"><textarea value={String(values.healthDetails)} onChange={(event) => update('healthDetails', event.target.value)} rows={4} /></Field>
    {select('skinPain', 'Possui dor, febre, inflamação, infecção ou lesão na área?')}
  </div>;
}

function AestheticAssessment({ values, update, select }: { values: Values; update: (key: string, value: string | string[]) => void; select: (key: string, label: string, required?: boolean, options?: { value: string; label: string }[]) => ReactNode }) {
  const skinTypes = [{ value: 'normal', label: 'Normal' }, { value: 'seca', label: 'Seca' }, { value: 'oleosa', label: 'Oleosa' }, { value: 'mista', label: 'Mista' }, { value: 'nao-sei', label: 'Não sei informar' }];
  return <div className="stack">
    {select('skinType', 'Tipo de pele', true, skinTypes)}
    <Field label="Condições da pele"><CheckboxGrid values={values.skinConditions as string[]} options={SKIN_CONDITIONS} onChange={(selection) => update('skinConditions', selection)} /></Field>
    <div className="field-grid compact-grid">
      {select('acids', 'Usa ou usou ácidos recentemente?')}
      {select('facialProcedure', 'Procedimento facial recente?')}
      {select('circulation', 'Possui varizes ou alteração circulatória?')}
      {select('restrictedArea', 'Há região que não deve ser manipulada?')}
    </div>
    <Field label="Detalhes adicionais"><textarea value={String(values.skinDetails)} onChange={(event) => update('skinDetails', event.target.value)} rows={4} /></Field>
  </div>;
}

function Habits({ values, update, select }: { values: Values; update: (key: string, value: string) => void; select: (key: string, label: string, required?: boolean, options?: { value: string; label: string }[]) => ReactNode }) {
  const frequency = [{ value: 'nunca', label: 'Nunca' }, { value: 'raramente', label: 'Raramente' }, { value: 'as-vezes', label: 'Às vezes' }, { value: 'frequentemente', label: 'Frequentemente' }];
  return <div className="stack">
    <aside className="notice">Estas informações ajudam a personalizar orientações antes e depois do atendimento.</aside>
    <div className="field-grid compact-grid">
      {select('sunExposure', 'Exposição solar sem proteção?', true, frequency)}
      {select('sunscreen', 'Usa protetor solar?', true, frequency)}
      {select('skincareRoutine', 'Possui rotina de cuidados com a pele?', true, YES_NO)}
      {select('hormones', 'Usa hormônios ou anticoncepcional?', true, YES_NO)}
    </div>
    <Field label="Produtos que utiliza, hábitos ou observações relevantes"><textarea value={String(values.habitsDetails)} onChange={(event) => update('habitsDetails', event.target.value)} rows={5} /></Field>
  </div>;
}

function Privacy({ values, update, select }: { values: Values; update: (key: string, value: string) => void; select: (key: string, label: string, required?: boolean, options?: { value: string; label: string }[]) => ReactNode }) {
  const imageOptions = [{ value: 'autorizo', label: 'Autorizo o uso de imagem' }, { value: 'nao-autorizo', label: 'Não autorizo o uso de imagem' }];
  return <div className="stack">
    <aside className="privacy-copy">Autorizo a Clau Estética a coletar e utilizar os dados pessoais e as informações de saúde fornecidas exclusivamente para avaliação, planejamento, execução e acompanhamento dos serviços, comunicação sobre o atendimento e cumprimento de obrigações aplicáveis.<br /><br />Estou ciente de que o acesso deve ser restrito às pessoas responsáveis pelo atendimento. Posso solicitar atualização ou correção das informações pelos canais oficiais da Clau Estética.</aside>
    <Field label="Consentimento de dados" required><ChoiceCards name="dataConsent" value={String(values.dataConsent)} options={[{ value: 'aceito', label: 'Li e autorizo o tratamento dos dados para as finalidades informadas.' }, { value: 'recuso', label: 'Não autorizo.' }]} onChange={(value) => update('dataConsent', value)} /></Field>
    {select('imageConsent', 'Autorização de imagem', true, imageOptions)}
    <p className="help-text">A autorização de divulgação é opcional e a recusa não impede o atendimento.</p>
  </div>;
}

function Confirmation({ values, update }: { values: Values; update: (key: string, value: string | boolean) => void }) {
  return <div className="stack">
    <aside className="notice">Revise suas respostas. Ao digitar seu nome abaixo, você registra sua confirmação eletrônica nesta ficha.</aside>
    <Field label="Digite seu nome completo" required><input value={String(values.fullName)} onChange={(event) => update('fullName', event.target.value)} required autoComplete="name" /></Field>
    <Field label="Data da confirmação" required><input type="date" value={String(values.confirmationDate)} onChange={(event) => update('confirmationDate', event.target.value)} required /></Field>
    <label className="confirm-card"><input type="checkbox" checked={Boolean(values.confirmed)} onChange={(event) => update('confirmed', event.target.checked)} required /><span>Confirmo que fui eu quem preencheu este formulário, li as declarações e concordo com as confirmações assinaladas.</span></label>
    <p className="help-text">Ao enviar a ficha, suas respostas serão encaminhadas ao e-mail responsável pelo atendimento.</p>
  </div>;
}
