import { env } from 'cloudflare:workers';
import { asText, createFormPdf, FormValues, formLines } from '../../../lib/form-pdf';

type RuntimeEnv = {
  FORM_RECIPIENT_EMAIL?: string;
  GMAIL_CLIENT_ID?: string;
  GMAIL_CLIENT_SECRET?: string;
  GMAIL_REFRESH_TOKEN?: string;
  GMAIL_SENDER_EMAIL?: string;
};

function toBase64(value: string) {
  const bytes = new TextEncoder().encode(value);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function toBase64Url(value: string) {
  return toBase64(value).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function wrapBase64(value: string) {
  return value.match(/.{1,76}/g)?.join('\r\n') ?? value;
}

function encodedHeader(value: string) {
  return `=?UTF-8?B?${toBase64(value.replace(/[\r\n]+/g, ' '))}?=`;
}

function buildMessage(values: FormValues, sender: string, recipient: string) {
  const fullName = asText(values.fullName).replace(/[\r\n]+/g, ' ');
  const lines = formLines(values);
  const body = [
    'Nova ficha de anamnese recebida.',
    'O PDF completo da ficha segue anexado a este e-mail.',
    '',
    ...lines,
  ].join('\r\n');
  const boundary = `form-${crypto.randomUUID()}`;
  const pdfAttachment = wrapBase64(bytesToBase64(createFormPdf(values)));

  return [
    `From: ${encodedHeader('Clau Estética')} <${sender}>`,
    `To: ${recipient}`,
    `Subject: ${encodedHeader(`Nova ficha de anamnese - ${fullName}`)}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: 8bit',
    '',
    body,
    '',
    `--${boundary}`,
    'Content-Type: application/pdf; name="ficha-anamnese.pdf"',
    'Content-Transfer-Encoding: base64',
    'Content-Disposition: attachment; filename="ficha-anamnese.pdf"',
    '',
    pdfAttachment,
    `--${boundary}--`,
  ].join('\r\n');
}

export async function POST(request: Request) {
  try {
    const payload = await request.json() as { values?: FormValues };
    const values = payload.values;
    if (!values || typeof values.fullName !== 'string' || typeof values.email !== 'string' || values.confirmed !== true) {
      return Response.json({ error: 'Dados incompletos.' }, { status: 400 });
    }

    const runtime = env as unknown as RuntimeEnv;
    const clientId = runtime.GMAIL_CLIENT_ID;
    const clientSecret = runtime.GMAIL_CLIENT_SECRET;
    const refreshToken = runtime.GMAIL_REFRESH_TOKEN;
    const sender = runtime.GMAIL_SENDER_EMAIL;
    const recipient = runtime.FORM_RECIPIENT_EMAIL;

    if (!clientId || !clientSecret || !refreshToken || !sender || !recipient) {
      return Response.json({ error: 'O envio não está configurado.' }, { status: 503 });
    }

    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: refreshToken,
        grant_type: 'refresh_token',
      }),
    });

    const tokenPayload = await tokenResponse.json() as { access_token?: string };
    if (!tokenResponse.ok || !tokenPayload.access_token) throw new Error('Falha ao obter acesso ao Gmail.');

    const messageResponse = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${tokenPayload.access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ raw: toBase64Url(buildMessage(values, sender, recipient)) }),
    });

    if (!messageResponse.ok) throw new Error('Falha ao enviar a mensagem pelo Gmail.');
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: 'Não foi possível enviar a ficha.' }, { status: 500 });
  }
}
